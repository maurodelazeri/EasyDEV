import React from 'react';
import TopContent from './components/TopContent';
import BottomContent from './components/BottomContent';

const Trade = () => (
  <div className="Tradecontainer">
    <TopContent />
    <BottomContent />
  </div>
);

export default Trade;
