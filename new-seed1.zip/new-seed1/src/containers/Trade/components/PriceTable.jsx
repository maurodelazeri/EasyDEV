import React from 'react';

const PriceTable = () => (
  <div className="PriceContent">
    <div className="row priceHeader">
      <div className="col-sm">
        Price
      </div>
      <div className="col-sm">
        Amount
      </div>
    </div>
    <table className="table table-dark">
      <tbody>
        <tr>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td colSpan="2" className="divider">26176.09</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
        </tr>
      </tbody>
    </table>
  </div>
);

export default PriceTable;
