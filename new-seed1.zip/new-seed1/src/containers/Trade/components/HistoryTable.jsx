import React from 'react';

const HistoryTable = () => (
  <div className="HistoryContent">
    <div className="priceHeader">
      Trade History
    </div>
    <table className="table table-dark">
      <tbody>
        <tr>
          <td>26195</td>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
          <td>26195</td>
        </tr>
        <tr>
          <td>26195</td>
          <td>26195</td>
          <td>26195</td>
        </tr>
      </tbody>
    </table>
  </div>
);

export default HistoryTable;
