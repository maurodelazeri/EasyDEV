import React from 'react';

const BottomContent = () => (
  <div className="ContentBottom">
    <div className="LogInContent">
        aaaaa
    </div>
    <div className="BuyContent">
      <div className="buyForm">
        <div className="available">
          <div className="labels">
            Available: --QC
          </div>
          <div className="labels">
            Deposits
          </div>
        </div>
        <div className="available">
          <div className="labels">
            Max Buy: 0.0000
          </div>
          <div className="labels">
            Withdrawals
          </div>
        </div>
        <form>
          <div className="form-group">
            <input type="text" className="form-control" id="a1" aria-describedby="emailHelp" placeholder="Price (QC)" />
          </div>
          <div className="form-group">
            <input type="text" className="form-control" id="a2" placeholder="Amount (BTC)" />
          </div>
          <button className="btn btn-danger btn-block">Buy</button>
        </form>
      </div>
      <div className="sellForm">
        <div className="available">
          <div className="labels">
            Available: --QC
          </div>
          <div className="labels">
            Deposits
          </div>
        </div>
        <div className="available">
          <div className="labels">
            Max Buy: 0.0000
          </div>
          <div className="labels">
            Withdrawals
          </div>
        </div>
        <form>
          <div className="form-group">
            <input
              type="text"
              className="form-control"
              id="a1"
              aria-describedby="emailHelp"
              placeholder="Price (QC)"
            />
          </div>
          <div className="form-group">
            <input type="text" className="form-control" id="a2" placeholder="Amount (BTC)" />
          </div>
          <button className="btn btn-danger btn-block">Buy</button>
        </form>
      </div>
    </div>
  </div>
);

export default BottomContent;
