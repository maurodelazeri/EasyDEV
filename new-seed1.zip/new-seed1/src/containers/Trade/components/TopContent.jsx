import React from 'react';
import PriceTable from './PriceTable';
import HistoryTable from './HistoryTable';

const TopContent = () => (
  <div className="ContentTop">
    <div className="TabContent">
      {/* Nav tabs  */}
      <ul className="nav nav-tabs" role="tablist">
        <li className="dropdown">
          <a className="dropdown-toggle" data-toggle="dropdown" href="#aa">TradingView </a>
          <ul className="dropdown-menu">
            <li><a href="#jquerytab" role="tab" data-toggle="tab">jQuery</a></li>
            <li><a href="#bootstab" role="tab" data-toggle="tab">Bootstrap</a></li>
          </ul>
        </li>
        <li className="active"><a href="#hometab" role="tab" data-toggle="tab">DepthChart</a></li>
        <li><a href="#javatab" role="tab" data-toggle="tab">Real-time Capital Flow</a></li>
        <li><a href="#csharptab" role="tab" data-toggle="tab">History Capital Flow</a></li>
        <li><a href="#mysqltab" role="tab" data-toggle="tab">Big Orders Monitoring</a></li>
      </ul>

      {/* Tab panes  */}
      <div className="tab-content">
        <div className="tab-pane active" id="hometab">Write something for home tab</div>
        <div className="tab-pane" id="javatab">
          The Java is an object-oriented programming
        </div>
        <div className="tab-pane" id="csharptab">C# is also a programming language</div>
        <div className="tab-pane" id="mysqltab">MySQL is a databased mostly used for web applications.</div>

        <div className="tab-pane" id="jquerytab">jQuery content here </div>
        <div className="tab-pane" id="bootstab">Bootstrap Content here </div>
          boottap
      </div>
    </div>
    <PriceTable />
    <HistoryTable />
  </div>
);

export default TopContent;
