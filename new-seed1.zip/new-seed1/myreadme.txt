In order to run, npm install and npm start.

Hi Mauro.
In stead of bonus, would you give me great long history feedback with 5 stars?
I wish you to end this contract with job completed successfully and 10 mark as extremely like.
I hope to see your great long story feedback in my profile after ending contract.

Alexander. :)